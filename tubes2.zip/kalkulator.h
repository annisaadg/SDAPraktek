#ifndef KALKULATOR_H
#define KALKULATOR_H
#include "boolean.h"
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#define nil NULL
#define info(p) (p)->node
#define prev(p) p->prev
#define top(s) (s).top

typedef char info[100];

typedef struct tElmtNode *Tnode;
typedef struct tElmtNode{
    info MathExpression;
    Tnode left;
    Tnode right;
}ElmtNode;

typedef struct telmstack *address;
typedef struct telmstack{
    Tnode node;
    address prev;
}tabStack;

typedef struct{
    address top;
}stack;

typedef Tnode RootTree;

struct Token
{
    info token;
};
void createstack(stack *s);
void createTree(RootTree *node);
address alokasi (info x);
void pushTree(stack *s, info x, Tnode left, Tnode right);
void dealokasi (address p);
void push (stack *s, info x);
void pop (stack *s, address *x);
boolean IsEmptyStack(stack s);
void toPostfix (info text, stack s, info *hasil);
int priority( info x);
boolean isoperator (info element);
boolean symop( char x);
void buildTree(stack s,Tnode *node, info text);
void Inorder(Tnode node);
int evaluate (Tnode root);
boolean isequal(info token,info operator);
#endif


