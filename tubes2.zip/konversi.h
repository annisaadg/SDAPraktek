#ifndef BILLINGS_H
#define BILLINGS_H
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 

void tanggalKurs();
void convertRupiahtoDollar();
void convertDollartoRupiah();
void convertRupiahtoYen();
void convertYentoRupiah();
void convertRupiahtoEuro();
void convertEurotoRupiah();

#endif
