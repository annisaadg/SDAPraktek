#include "segitiga.h"
#include <stdio.h>

int main(){
	BARANG P;
	char name,member;
	int price,dis,TOTAL;
	printf("Nama Barang	:	");
	scanf("%s", &name);
	printf("Harga Barang	:	");
	scanf("%d", &price);
	CreateBarang(&name,price);
	printf("Member? [Y/N]	:	");
	scanf("%s",&member);
	
	printf("===== Invoice =====\n");
	TampilBarang(P);
	if(member=='Y'){
		printf("\nDisc 50%");
		TOTAL = GetHargaDiskon(P,50);
	}else{
		TOTAL = price;
	}
	
	printf("Total Tagihan: %d", TOTAL);
	
	return 0;
}
