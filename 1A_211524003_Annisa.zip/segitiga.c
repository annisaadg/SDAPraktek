/* Program : segitiga.c
Deskripsi : Header ADT Barang
oleh : Lukmannul Hakim Firdaus
Tgl/Version :
*/

#include "segitiga.h"
#include <stdio.h>

BARANG CreateBarang(char *nama, long harga){
	BARANG P;
	P.nama_barang = nama;
	P.harga = harga;
	return P;
}

void SetNamaBarang(BARANG barang, char *nama){
	barang.nama_barang = nama;
}

char *GetNamaBarang(BARANG barang){
	return barang.nama_barang;
}

void SetHargaBarang(BARANG barang, long harga){
	barang.harga = harga;
}

int GetHargaBarang(BARANG barang){
	return barang.harga;
}

int GetHargaDiskon(BARANG barang, float diskon){
	int disc;
	disc = (barang.harga-(barang.harga*diskon/100));
	return disc;
}

void TampilBarang(BARANG barang){
	printf("Nama Barang: %s\nHarga Barang: %d\n",barang.nama_barang, barang.harga);
}
